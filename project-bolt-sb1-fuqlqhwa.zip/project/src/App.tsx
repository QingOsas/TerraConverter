import React, { useState, useEffect } from 'react';
import { FileUpload } from './components/FileUpload';
import { ConversionResultView } from './components/ConversionResult';
import { FileCode } from 'lucide-react';
import type { FileUploadState } from './types';
import axios from 'axios';

function App() {
  const [state, setState] = useState<FileUploadState>({
    file: null,
    loading: false,
    error: null,
    result: null
  });

  const [serverStatus, setServerStatus] = useState<'checking' | 'online' | 'offline'>('checking');

  useEffect(() => {
    // Check if the server is running
    axios.get('http://localhost:3000/')
      .then(() => setServerStatus('online'))
      .catch(() => setServerStatus('offline'));
  }, []);

  const handleFileSelect = async (file: File) => {
    setState(prev => ({ ...prev, file, loading: true, error: null }));
    
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await axios.post('http://localhost:3000/api/convert', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      setState(prev => ({
        ...prev,
        loading: false,
        result: response.data
      }));
    } catch (error) {
      setState(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to convert file. Please try again.'
      }));
    }
  };

  if (serverStatus === 'offline') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center p-8 bg-white rounded-lg shadow-md">
          <FileCode className="mx-auto h-12 w-12 text-red-600" />
          <h1 className="mt-4 text-2xl font-bold text-gray-900">Server Unavailable</h1>
          <p className="mt-2 text-gray-600">
            The conversion server is not running. Please start the server with <code className="bg-gray-100 px-2 py-1 rounded">npm run dev</code>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <FileCode className="mx-auto h-12 w-12 text-blue-600" />
          <h1 className="mt-4 text-3xl font-extrabold text-gray-900">
            ARM/Bicep to Terraform Converter
          </h1>
          <p className="mt-2 text-lg text-gray-600">
            Convert your Azure ARM templates and Bicep files to Terraform configuration
          </p>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <FileUpload
            onFileSelect={handleFileSelect}
            acceptedTypes={['.json', '.bicep']}
          />

          {state.loading && (
            <div className="mt-8 text-center">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-blue-600 border-t-transparent"></div>
              <p className="mt-2 text-gray-600">Converting your file...</p>
            </div>
          )}

          {state.error && (
            <div className="mt-8 bg-red-50 border border-red-200 rounded-md p-4">
              <p className="text-red-700">{state.error}</p>
            </div>
          )}

          {state.result && <ConversionResultView result={state.result} />}
        </div>
      </div>
    </div>
  );
}

export default App;