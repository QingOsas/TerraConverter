export interface ConversionResult {
  mainTf: string;
  providersTf: string;
  variablesTf: string;
  tfvars: string;
}

export interface FileUploadState {
  file: File | null;
  loading: boolean;
  error: string | null;
  result: ConversionResult | null;
}