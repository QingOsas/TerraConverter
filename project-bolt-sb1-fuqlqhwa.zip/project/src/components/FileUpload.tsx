import React, { useCallback } from 'react';
import { Upload } from 'lucide-react';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  acceptedTypes: string[];
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, acceptedTypes }) => {
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      if (acceptedTypes.includes(file.type) || 
          acceptedTypes.some(type => file.name.endsWith(type))) {
        onFileSelect(file);
      }
    }
  }, [onFileSelect, acceptedTypes]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      onFileSelect(files[0]);
    }
  }, [onFileSelect]);

  return (
    <div
      className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-500 transition-colors"
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      <Upload className="mx-auto h-12 w-12 text-gray-400" />
      <p className="mt-4 text-lg font-medium text-gray-900">
        Drag and drop your file here
      </p>
      <p className="mt-2 text-sm text-gray-500">
        or
      </p>
      <label className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 cursor-pointer">
        <input
          type="file"
          className="sr-only"
          onChange={handleFileInput}
          accept={acceptedTypes.join(',')}
        />
        Browse files
      </label>
      <p className="mt-2 text-xs text-gray-500">
        Supported formats: ARM templates (.json) and Bicep files (.bicep)
      </p>
    </div>
  );
};