import React from 'react';
import { Download } from 'lucide-react';
import type { ConversionResult } from '../types';
import JSZip from 'jszip';

interface ConversionResultProps {
  result: ConversionResult;
}

export const ConversionResultView: React.FC<ConversionResultProps> = ({ result }) => {
  const handleDownload = async () => {
    const zip = new JSZip();
    
    zip.file('main.tf', result.mainTf);
    zip.file('providers.tf', result.providersTf);
    zip.file('variables.tf', result.variablesTf);
    zip.file('terraform.tfvars', result.tfvars);
    
    const content = await zip.generateAsync({ type: 'blob' });
    const url = window.URL.createObjectURL(content);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'terraform-config.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="mt-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Conversion Result</h2>
        <button
          onClick={handleDownload}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          <Download className="h-4 w-4 mr-2" />
          Download Files
        </button>
      </div>
      
      <div className="grid grid-cols-1 gap-4">
        {Object.entries(result).map(([filename, content]) => (
          <div key={filename} className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-medium mb-2">{filename}</h3>
            <pre className="bg-gray-800 text-gray-100 p-4 rounded overflow-x-auto">
              <code>{content}</code>
            </pre>
          </div>
        ))}
      </div>
    </div>
  );
};