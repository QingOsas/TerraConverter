import { randomUUID } from 'crypto';

// Resource type mapping from Azure to Terraform
const resourceTypeMap = {
  'Microsoft.Storage/storageAccounts': 'azurerm_storage_account',
  'Microsoft.Network/virtualNetworks': 'azurerm_virtual_network',
  'Microsoft.Network/networkInterfaces': 'azurerm_network_interface',
  'Microsoft.Network/publicIPAddresses': 'azurerm_public_ip',
  'Microsoft.Network/networkSecurityGroups': 'azurerm_network_security_group',
  'Microsoft.Compute/virtualMachines': 'azurerm_virtual_machine',
  'Microsoft.Web/sites': 'azurerm_app_service',
  'Microsoft.KeyVault/vaults': 'azurerm_key_vault',
  'Microsoft.Sql/servers': 'azurerm_sql_server',
  'Microsoft.Sql/servers/databases': 'azurerm_sql_database',
  'Microsoft.ContainerRegistry/registries': 'azurerm_container_registry',
  'Microsoft.ContainerService/managedClusters': 'azurerm_kubernetes_cluster'
};

// SKU mapping for various resources
const skuMap = {
  'Standard_LRS': 'Standard',
  'Premium_LRS': 'Premium',
  'StandardV2': 'Standard_v2',
  'PremiumV2': 'Premium_v2'
};

// Helper function to sanitize resource names
const sanitizeName = (name) => {
  return name.toLowerCase().replace(/[^a-z0-9]/g, '_');
};

// Helper function to generate a resource name
const generateResourceName = (resourceType, name) => {
  const sanitizedName = sanitizeName(name);
  return `${resourceType}_${sanitizedName}_${randomUUID().split('-')[0]}`;
};

// Helper function to generate variable definitions
const generateVariables = (resources) => {
  const variables = {
    location: {
      type: 'string',
      description: 'The Azure region where resources will be created',
      default: 'westus2'
    },
    environment: {
      type: 'string',
      description: 'Environment name (dev, staging, prod)',
      default: 'dev'
    },
    resource_group_name: {
      type: 'string',
      description: 'Name of the resource group',
      default: 'terraform-resources'
    },
    tags: {
      type: 'map(string)',
      description: 'Tags to apply to all resources',
      default: {
        environment: 'dev',
        managed_by: 'terraform'
      }
    }
  };

  // Add resource-specific variables based on the template
  resources.forEach(resource => {
    if (resource.sku) {
      const skuVarName = `${sanitizeName(resource.name)}_sku`;
      variables[skuVarName] = {
        type: 'string',
        description: `SKU for ${resource.name}`,
        default: resource.sku.name || 'Standard'
      };
    }
  });

  return Object.entries(variables)
    .map(([name, config]) => {
      const defaultValue = typeof config.default === 'object' 
        ? `{\n    ${Object.entries(config.default).map(([k, v]) => `${k} = "${v}"`).join('\n    ')}\n  }`
        : `"${config.default}"`;
      
      return `variable "${name}" {
  type        = ${config.type}
  description = "${config.description}"
  default     = ${defaultValue}
}`;
    })
    .join('\n\n');
};

// Helper function to generate provider configuration
const generateProvider = () => {
  return `# Configure the Azure Provider
provider "azurerm" {
  features {}
}

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.0"
    }
  }
  
  required_version = ">= 1.0"
}

# Create a resource group
resource "azurerm_resource_group" "main" {
  name     = var.resource_group_name
  location = var.location
  tags     = var.tags
}`;
};

// Convert ARM template to Terraform
export const convertARMToTerraform = async (armTemplate) => {
  try {
    const template = JSON.parse(armTemplate);
    const resources = template.resources || [];
    
    // Generate main.tf content
    const mainTf = resources
      .map(resource => {
        const terraformType = resourceTypeMap[resource.type] || resource.type.toLowerCase().replace('microsoft.', 'azurerm_');
        const resourceId = generateResourceName(terraformType.split('_').pop(), resource.name);
        
        let properties = [];
        
        // Common properties
        properties.push(`  name                = "${resource.name}"`);
        properties.push(`  resource_group_name = azurerm_resource_group.main.name`);
        properties.push(`  location            = azurerm_resource_group.main.location`);
        
        // Handle SKU if present
        if (resource.sku) {
          const skuName = skuMap[resource.sku.name] || resource.sku.name;
          properties.push(`  sku                 = "${skuName}"`);
        }

        // Handle specific resource properties
        if (resource.properties) {
          if (resource.properties.administratorLogin) {
            properties.push(`  administrator_login          = "${resource.properties.administratorLogin}"`);
            properties.push(`  administrator_login_password = var.${sanitizeName(resource.name)}_admin_password`);
          }
          
          if (resource.properties.virtualNetworkRules) {
            properties.push(`  virtual_network_rules {
    subnet_id = azurerm_subnet.main.id
  }`);
          }
        }

        // Add tags
        properties.push('  tags = var.tags');

        return `resource "${terraformType}" "${resourceId}" {
${properties.join('\n')}
}`;
      })
      .join('\n\n');

    // Generate tfvars with default values
    const tfvars = `location            = "westus2"
environment         = "dev"
resource_group_name = "terraform-resources"

tags = {
  environment = "dev"
  managed_by  = "terraform"
}`;

    return {
      mainTf,
      providersTf: generateProvider(),
      variablesTf: generateVariables(resources),
      tfvars
    };
  } catch (error) {
    throw new Error(`Failed to convert ARM template: ${error.message}`);
  }
};

// Convert Bicep to Terraform
export const convertBicepToTerraform = async (bicepContent) => {
  try {
    // Parse Bicep content and extract resource definitions
    const resources = parseBicepContent(bicepContent);
    
    // Generate main.tf content
    const mainTf = resources
      .map(resource => {
        const terraformType = resourceTypeMap[resource.type] || `azurerm_${resource.type.toLowerCase()}`;
        const resourceId = generateResourceName(terraformType.split('_').pop(), resource.name);
        
        return `resource "${terraformType}" "${resourceId}" {
  name                = "${resource.name}"
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  tags                = var.tags
  
  # Resource-specific properties would be added here
}`;
      })
      .join('\n\n');

    return {
      mainTf,
      providersTf: generateProvider(),
      variablesTf: generateVariables(resources),
      tfvars: 'location = "westus2"\nenvironment = "dev"\nresource_group_name = "terraform-resources"'
    };
  } catch (error) {
    throw new Error(`Failed to convert Bicep file: ${error.message}`);
  }
};

// Helper function to parse Bicep content (basic implementation)
function parseBicepContent(content) {
  const resources = [];
  const lines = content.split('\n');
  
  let currentResource = null;
  
  lines.forEach(line => {
    // Basic resource definition detection
    const resourceMatch = line.match(/resource\s+(\w+)\s+['"]([^'"]+)['"]/);
    if (resourceMatch) {
      currentResource = {
        type: resourceMatch[1],
        name: resourceMatch[2],
        properties: {}
      };
      resources.push(currentResource);
    }
    
    // Basic property detection
    if (currentResource) {
      const propertyMatch = line.match(/\s*(\w+):\s*['"]([^'"]+)['"]/);
      if (propertyMatch) {
        currentResource.properties[propertyMatch[1]] = propertyMatch[2];
      }
    }
  });
  
  return resources;
}